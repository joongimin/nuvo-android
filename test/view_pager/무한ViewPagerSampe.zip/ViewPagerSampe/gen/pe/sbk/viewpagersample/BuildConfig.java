/** Automatically generated file. DO NOT MODIFY */
package pe.sbk.viewpagersample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}