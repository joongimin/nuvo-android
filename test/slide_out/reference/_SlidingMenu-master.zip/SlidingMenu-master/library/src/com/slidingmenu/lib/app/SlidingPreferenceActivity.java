package com.slidingmenu.lib.app;

import android.preference.PreferenceActivity;

public class SlidingPreferenceActivity extends PreferenceActivity {

}
