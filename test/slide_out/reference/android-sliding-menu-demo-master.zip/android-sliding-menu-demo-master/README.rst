========
 README
========

What is it?
===========

This is a demo project to explore how to implement a sliding menu like Facebook and others use.

License
=======

Released under version 2.0 of the `Apache License <http://www.apache.org/licenses/LICENSE-2.0>`_
