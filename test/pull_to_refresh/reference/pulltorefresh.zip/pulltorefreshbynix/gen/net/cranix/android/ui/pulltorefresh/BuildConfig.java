/** Automatically generated file. DO NOT MODIFY */
package net.cranix.android.ui.pulltorefresh;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}